import React, { useState, useEffect } from "react";
import { 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Edit3, 
  Link as LinkIcon, 
  Calendar,
  Loader2,
  AlertCircle
} from "lucide-react";
import { getBannerList } from "../api/bannerManagementApi";

const Banners = () => {
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchBanners();
  }, []);

  const fetchBanners = async () => {
    try {
      setLoading(true);
      const response = await getBannerList();
      if (response.status) {
        setBanners(response.data);
      } else {
        setError("Could not retrieve banner data.");
      }
    } catch (err) {
      setError("Failed to connect to the server. Please check your login session.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="animate-spin text-[#632281] mb-4" size={48} />
        <p className="text-[#632281] font-bold animate-pulse text-lg tracking-tight">Syncing Banners...</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 bg-[#FAFAFB] min-h-screen">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-7 rounded-3xl shadow-sm border border-purple-100">
        <div>
          <h2 className="text-2xl font-black text-gray-800 tracking-tight">Banner Management</h2>
          <p className="text-purple-500 text-sm font-semibold">Displaying all active homepage sliders</p>
        </div>
        <button 
          className="flex items-center justify-center gap-2 bg-[#632281] text-white px-7 py-3.5 rounded-2xl shadow-lg shadow-purple-100 hover:bg-[#4a1961] transition-all font-bold active:scale-95"
        >
          <Plus size={20} strokeWidth={3} />
          <span>Create New Banner</span>
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 text-red-700 p-5 rounded-2xl font-bold flex items-center gap-4 animate-in fade-in slide-in-from-top-2">
          <AlertCircle size={24} /> 
          <div>
             <p>Error Encountered</p>
             <p className="text-sm font-medium opacity-80">{error}</p>
          </div>
        </div>
      )}

      {/* Grid Layout */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {banners.map((banner) => (
          <div key={banner.id} className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden flex flex-col md:flex-row group hover:shadow-2xl hover:shadow-purple-100/50 transition-all duration-500">
            
            {/* Left: Banner Visual */}
            <div className="md:w-5/12 relative h-60 md:h-auto overflow-hidden">
              <img 
                src={banner.image[0]} 
                alt={banner.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="absolute top-5 left-5">
                <span className="bg-[#632281] text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-xl">
                  POS: {banner.position}
                </span>
              </div>
            </div>

            {/* Right: Info & Stats */}
            <div className="md:w-7/12 p-8 flex flex-col">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-xl font-black text-gray-800 mb-1">{banner.title}</h3>
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${banner.status === 1 ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                    {banner.status === 1 ? '• Active' : '• Hidden'}
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-8">
                <div className="flex items-center gap-3 text-sm text-gray-500">
                  <div className="p-2 bg-purple-50 rounded-lg text-purple-600"><Calendar size={14} /></div>
                  <span className="font-bold">Added: {new Date(banner.created_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-500">
                   <div className="p-2 bg-purple-50 rounded-lg text-purple-600"><LinkIcon size={14} /></div>
                  <span className="font-bold truncate max-w-[200px]">{banner.link || 'Internal Link Only'}</span>
                </div>
              </div>

              {/* Thumbnails of the image collection */}
              <div className="mb-8">
                <p className="text-[10px] font-black text-purple-300 uppercase tracking-widest mb-3">Group Assets ({banner.image.length})</p>
                <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-hide">
                  {banner.image.map((img, idx) => (
                    <img 
                      key={idx} 
                      src={img} 
                      className="w-14 h-14 rounded-xl object-cover border-2 border-transparent hover:border-[#632281] transition-all cursor-zoom-in shadow-sm" 
                      alt="asset"
                    />
                  ))}
                </div>
              </div>

              {/* Action Toolbar */}
              <div className="mt-auto flex gap-4">
                <button 
                  className="flex-1 flex items-center justify-center gap-2 bg-purple-50 text-[#632281] py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-[#632281] hover:text-white transition-all shadow-sm"
                >
                  <Edit3 size={16} /> Edit
                </button>
                <button 
                  className="flex-1 flex items-center justify-center gap-2 bg-red-50 text-red-600 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all shadow-sm"
                >
                  <Trash2 size={16} /> Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Banners;