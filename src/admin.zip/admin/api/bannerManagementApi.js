import api from './axios'; 

export const getBannerList = async () => {
  const response = await api.get('/api/banner/list');
  return response.data; 
};

export const addBanner = async (bannerData) => {
  const formData = new FormData();
  formData.append('title', bannerData.title);
  formData.append('position', bannerData.position);
  formData.append('status', bannerData.status);

  if (bannerData.imageFiles) {
    // Matches the images[] requirement in your screenshot
    Array.from(bannerData.imageFiles).forEach((file) => {
      formData.append('images[]', file);
    });
  }

  const response = await api.post('/api/banner/add', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

export const deleteBanner = async (id) => {
  const response = await api.delete(`/api/banner/delete/${id}`);
  return response.data;
};

export const updateBannerStatus = async (id, payload) => {
  // Payload should be: { status, title, position }
  const response = await api.post(`/api/banner/update-status/${id}`, payload);
  return response.data;
};